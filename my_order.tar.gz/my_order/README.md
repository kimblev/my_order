#### Introduction
  - At install, this module creates three things: a form to collect meal orders (/my-order), a the content type (my_order_form) to hold form submissions and a view (/my-order-orders) to list order submissions.

#### Installation
  - Install as you would normally install a contributed Drupal module. Visit:
   https://www.drupal.org/node/1897420 for further information.

#### Requirements
  - views (drupal core)

#### Version Compatibility
  - This module was built for Drupal version 9.x. It has not been tested on other versions.

