<?php

/**
 * @file
 * Contains \Drupal\my_order\Form\MyOrderForm.
 */

namespace Drupal\my_order\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\node\Entity\Node;
use Drupal\user\Entity\User;

/**
 * My Order form.
 */
class MyOrderForm extends FormBase {
  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'my_order_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $form['myordername'] = [
      '#type' => 'textfield',
      '#title' => t('Name'),
      '#size' => 60,
      '#maxlength' => 60,
      '#required' => TRUE,
    ];	 
    $form['myorderemail'] = [
      '#type' => 'email',
      '#title' => t('Email'),
      '#size' => 60,
      '#maxlength' => 100,
      '#required' => TRUE,
    ];
    $form['myordermealtype'] = [
      '#type' => 'select',
      '#title' => $this
        ->t('Select meal type'),
      '#options' => [
        'meat' => $this
          ->t('Meat'),
        'fish' => $this
          ->t('Fish'),
        'vegetarian' => $this
          ->t('Vegetarian'),
      ],
    ];
    $form['myorderdietrestrictions'] = [
      '#type' => 'select',
      '#title' => $this
        ->t('Select diet restrictions'),
      '#options' => [
        'none' => $this
          ->t('None'),
        'gluten-free' => $this
          ->t('Gluten-Free'),
        'dairy-free' => $this
          ->t('Dairy-Free'),
        'other' => $this
          ->t('Other (use field below)'),
      ],
    ];
    $form['myorderspecialinstructions'] = [
      '#type' => 'textarea',
      '#rows' => 2,
      '#maxlength' => 255,
      '#title' => $this
        ->t('Special instructions'),
    ];
    $form['submit'] = [
      '#type' => 'submit',
      '#value' => t('Submit'),
    ];
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
	/**
	 * Validate name
	 * Only alphabets and space are allowed
     */
    $myordername = trim($form_state->getValue('myordername'));
    
    if (!preg_match("/^([a-zA-Z ]+)$/", $myordername)) {
	    $form_state->setErrorByName('myordername', $this->t('Invalid characters in name'));
    }
    
    /**
     * Validate email address
     */
    $myorderemail = trim($form_state->getValue('myorderemail'));
  
    if ($myorderemail !== '' && !\Drupal::service('email.validator')->isValid($myorderemail)) {
      $form_state->setErrorByName('myorderemail', $this->t('Invalid email address'));  
    }

  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    /**
     * Get user form input
     */
    $myordername = trim($form_state->getValue('myordername'));
    $myorderemail = trim($form_state->getValue('myorderemail'));
    $myordermealtype = trim($form_state->getValue('myordermealtype'));
    $myorderdietrestrictions = trim($form_state->getValue('myorderdietrestrictions'));
    $myorderspecialinstructions = trim($form_state->getValue('myorderspecialinstructions'));

  
    /**
     * Save my_form data in content type "My Order Form"
     */
     $node = Node::create(array(
     'type' => 'my_order_form',
     'langcode' => 'en',
     'created' => \Drupal::time()->getRequestTime(),
     'changed' => \Drupal::time()->getRequestTime(),
     // Default admin user ID.
     'uid' => 1,
     'title' => $myordername . t(' meal order'),
     'field_my_order_name' => $myordername,
     'field_my_order_email' => $myorderemail,
     'field_my_order_meal_type' => $myordermealtype,
     'field_my_order_diet_restrictions' => $myorderdietrestrictions,
     'field_my_order_special_instr' => $myorderspecialinstructions,
     'status' => 1,
     'promote' => 0,
    ));
    $node->save();

    /**
     * Send the confirmation email 
     */
    if (!empty($myorderemail)) {
      /**
       * Send email
       */
      $mail_manager = \Drupal::service('plugin.manager.mail');
      $langcode = \Drupal::currentUser()->getPreferredLangcode();
      $params['message']['myordername'] = $myordername;
      $params['message']['myorderemail'] = $myorderemail;
      $params['message']['myordermealtype'] = $myordermealtype;
      $params['message']['myorderdietrestrictions'] = $myorderdietrestrictions;
      $params['message']['myorderspecialinstructions'] = $myorderspecialinstructions;

      $to = $myorderemail;

      $result = $mail_manager->mail('my_order', 'my_order_notify', $to, $langcode, $params, NULL, 'true');
    }

    /**
     * Send the admin notification email 
     */
    if (!empty($myorderspecialinstructions)) {
      /**
       * Get admin email 
       */
      $account = User::load(1);
      $myorderadminemail = $account->getEmail();
      /**
       * Send admin email
       */
      $mail_manager = \Drupal::service('plugin.manager.mail');
      $langcode = \Drupal::currentUser()->getPreferredLangcode();
      $params['message']['myordername'] = $myordername;
      $params['message']['myorderemail'] = $myorderemail;
      $params['message']['myordermealtype'] = $myordermealtype;
      $params['message']['myorderdietrestrictions'] = $myorderdietrestrictions;
      $params['message']['myorderspecialinstructions'] = $myorderspecialinstructions;

      $to = $myorderadminemail;

      $result = $mail_manager->mail('my_order', 'my_order_admin_notify', $to, $langcode, $params, NULL, 'true');
    }
    /**
     * Display thanks message to the visitor
     */
    \Drupal::messenger()->addStatus(t('Thank you ' . $myordername . '! Your meal order has been submitted successfully.'));
  }
 
}
